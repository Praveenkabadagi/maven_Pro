package com.example.HarmanAssignment.HarmanAssignment.model;

public class GameCharacter {
    private String name;
    private String characterType;
    private Integer max_power;
    private Integer used;

    public String getName() {
        return name;
    }

    public GameCharacter(String name, String characterType, Integer maxPower) {
        this.name = name;
        this.characterType = characterType;
        this.max_power = maxPower;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCharacterType() {
        return characterType;
    }

    public void setCharacterType(String characterType) {
        this.characterType = characterType;
    }

    public Integer getMax_power() {
        return max_power;
    }

    public void setMax_power(Integer max_power) {
        this.max_power = max_power;
    }

    @Override
    public String toString() {
        String output = "Name: " + getName() + " maxPower: " + getMax_power() ;

        return output;
    }
}
