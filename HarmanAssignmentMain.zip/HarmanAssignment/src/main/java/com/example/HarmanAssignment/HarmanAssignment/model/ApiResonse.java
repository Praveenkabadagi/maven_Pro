package com.example.HarmanAssignment.HarmanAssignment.model;

import java.util.List;

public class ApiResonse {
    private String name;
    private List<Object> character;

    public ApiResonse(String name, List<Object> character) {
        this.name = name;
        this.character = character;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Object> getCharacter() {
        return character;
    }

    public void setCharacter(List<Object> character) {
        this.character = character;
    }
}
