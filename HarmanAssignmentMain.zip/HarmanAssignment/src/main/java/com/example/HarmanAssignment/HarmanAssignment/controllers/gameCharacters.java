package com.example.HarmanAssignment.HarmanAssignment.controllers;
import com.example.HarmanAssignment.HarmanAssignment.service.charactersService;
import com.sun.istack.internal.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/")
public class gameCharacters {

    @Autowired
    private charactersService service;

    @GetMapping(value = "/getCharacter/{name}")
    public Integer addAccount(@PathVariable String name) {

        return this.service.getHeroes(name);
    }
}
