package com.example.HarmanAssignment.HarmanAssignment.service;
import  java.lang.Object.*;
import com.example.HarmanAssignment.HarmanAssignment.model.ApiResonse;
import com.example.HarmanAssignment.HarmanAssignment.model.GameCharacter;
import com.fasterxml.jackson.databind.util.JSONPObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import com.querydsl.core.Tuple;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Service
public class charactersService {
    private static final Logger logger = LoggerFactory.getLogger(charactersService.class);
    private HashMap<String,GameCharacter> characters=new HashMap<>();

    @Scheduled(fixedRate = 10000)
    @Async
    public void getApiAvengersHeroes(){
        String URI="http://www.mocky.io/v2/5ecfd5dc3200006200e3d64b";
        RestTemplate restTemplate=new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        HttpEntity entity = new HttpEntity<>(httpHeaders);
        ResponseEntity<HashMap> res=restTemplate.exchange(URI, HttpMethod.GET,entity,HashMap.class);
        ArrayList<HashMap<String,Object>> temp8= (ArrayList<HashMap<String, Object>>) res.getBody().get("character");
        temp8.forEach((r)->{
             characters.put((String) r.get("name"),new GameCharacter((String) r.get("name"),"Avengers", (Integer) r.get("max_power")));
        });
        System.out.println("Avengers Api called");
    }

    @Scheduled(fixedRate = 10000)
    @Async
    public void getApiMutants(){
        String URI="http://www.mocky.io/v2/5ecfd6473200009dc1e3d64e";
        RestTemplate restTemplate=new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        HttpEntity entity = new HttpEntity<>(httpHeaders);
        ResponseEntity<HashMap> res=restTemplate.exchange(URI, HttpMethod.GET,entity,HashMap.class);
        ArrayList<HashMap<String,Object>> temp8= (ArrayList<HashMap<String, Object>>) res.getBody().get("character");
        temp8.forEach((r)->{
            characters.put((String) r.get("name"),new GameCharacter((String) r.get("name"),"Mutant", (Integer) r.get("max_power")));
        });
        System.out.println("Mutants Api called");
    }

    @Scheduled(fixedRate = 10000)
    @Async
    public void getApiAntiHeroes(){
        String URI="http://www.mocky.io/v2/5ecfd630320000f1aee3d64d";
        RestTemplate restTemplate=new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        HttpEntity entity = new HttpEntity<>(httpHeaders);
        ResponseEntity<String> res=restTemplate.exchange(URI, HttpMethod.GET,entity,String.class);
//        ArrayList<HashMap<String,Object>> temp8= (ArrayList<HashMap<String, Object>>) res.getBody().get("character");
//        temp8.forEach((r)->{
//            characters.put((String) r.get("name"),new GameCharacter((String) r.get("name"),"Anti Heroes", (Integer) r.get("max_power")));
//        });
        // json is not proper i think , is extra
//        System.out.println(res.getBody());
        //
        System.out.println("Anti heroes Api called");
    }

    public Integer getHeroes(String name){
        return this.characters.get(name).getMax_power();
    }



}
