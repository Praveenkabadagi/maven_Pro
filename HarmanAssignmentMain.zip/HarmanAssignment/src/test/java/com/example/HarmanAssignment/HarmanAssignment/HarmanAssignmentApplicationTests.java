package com.example.HarmanAssignment.HarmanAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarmanAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
